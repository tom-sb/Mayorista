import sys
from cliente.tests import BasicTest
#from comprar.tests 
from factura.tests import TestFactura
#from facturar
from inventario.TestInventario import TestInventario
from proveedor.tests import TestProveedor
from usuario.tests import PerfilTestCase

#def helloworld(out):
 #   out.write("hello\n")
